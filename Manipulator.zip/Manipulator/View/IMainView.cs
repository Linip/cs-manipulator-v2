﻿namespace Manipulator.View
{
    public interface IMainView
    {
        Presenter.MainPresenter Presenter { set; }
    }
}