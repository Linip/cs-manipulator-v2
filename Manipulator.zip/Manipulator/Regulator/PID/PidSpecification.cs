﻿namespace Manipulator.Regulator.PID
{
    public class PidSpecification
    {
        public double Proportional;
        public double Integrating;
        public double Differentiating;
    }
}